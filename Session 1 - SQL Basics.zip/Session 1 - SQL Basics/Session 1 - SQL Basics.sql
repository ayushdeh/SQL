
/*----------------------------------- Session 1 - SQL Basics ------------------------------------------- */

----------------------------------- Using Sakila database for our course ---------------------------------

USE sakila;

------------------------- SELECT queries to view data from tables - Actor table -----------------------------

SELECT * FROM `actor` ;   

SELECT * from actor LIMIT 10;

SELECT first_name, last_name FROM actor ;

SELECT * from address ;

select * from actor ;